# -*- coding: utf-8 -*-
"""
@File    : ${NAME}.py
@Time    : ${DATE} ${TIME}
@Author  : ayami_L
@URL     : www.ayamil.com
@Desc    : 记得写注释啊！！！
"""



if __name__ == '__main__':
    pass